package com.example.auth_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
