package com.example.login_trial_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
